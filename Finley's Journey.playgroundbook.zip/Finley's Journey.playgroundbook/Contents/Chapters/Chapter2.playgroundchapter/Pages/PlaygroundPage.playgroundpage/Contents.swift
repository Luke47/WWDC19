/*:
 # Jumping into Uncertainty
 
 As Finley approached the river, he discovered that it was full of life. He saw many fish in beautiful colors and also some dangerous looking ones.
 
 He realize that in order to reach his goal he would need to overcome different obstacles and dangers. Maybe it would be a good idea to make some new friends along the way?
 
 ## How to Play?
 It is happening - Finley finally left his comfort zone and decided to make a new experience. To reach his goal of seeing the ocean he needs your help.
 
 **Collect**
 
 ![Friendly Fish](friendlyFish.png)
 
 Move over these fish to add them as followers to your swarm to help you fight other fish.
 
 **Avoid**
 
 ![Enemy Fish](enemyFish.png)

 Evade these dangerous fish and do not let them get in contact with Finley or one of his followers.
 
 - If they **hit followers**: The left enemy will eat up to 10 followers until he is defeated by the swarm. The right enemy eats up to 5 followers.
 - If they **hit Finley**: If he has at least 5 followers, they will sacrifice themselves for him. If he has fewer than 5 followers, he will get eaten and the game is lost.
 
 **WIN**: Collect 30 followers.
 
 **LOSE**: Finley gets touched by an enemy fish and has less than 5 followers.
 
 ## Ready?
 Call the function `startGame()` below and hit "Run My Code".
 */
//#-code-completion(everything, hide)
//#-hidden-code
import Foundation
import PlaygroundSupport

let page = PlaygroundPage.current
page.needsIndefiniteExecution = true
let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy

class LiveViewListener: PlaygroundRemoteLiveViewProxyDelegate {
    
    func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy,
                             received message: PlaygroundValue) {
        
        guard case .boolean(let win) = message else {
            return
        }
        
        if win {
            PlaygroundPage.current.assessmentStatus = .pass(message: "Wohooo! You guided Finley safely through the river. With your help and the help of his new friends, he reached his goal of travelling to the ocean. To see what is next, please advance to the [next page](@next).")
        } else {
            PlaygroundPage.current.assessmentStatus = .fail(hints: ["Use startGame() to restart the game. Try to collect the friendly fish and to avoid the enemy fish. Do not give up - you can make it!"], solution: nil)
        }
    }
    
    func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) { }
}

let listener = LiveViewListener()
proxy.delegate = listener

func startGame() {
    
    sendValue(.boolean(true))
    
}

//#-end-hidden-code

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, startGame())
/*#-editable-code*/<#Please enter your code here.#>/*#-end-editable-code*/

/*:
- Notes:
    This page is best experienced if you extend the live view to fullscreen.

    If you want to restart just hit "Stop" and then "Run My Code".

*/

