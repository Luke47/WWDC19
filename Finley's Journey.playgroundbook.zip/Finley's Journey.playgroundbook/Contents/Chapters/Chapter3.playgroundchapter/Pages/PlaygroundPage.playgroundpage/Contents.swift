/*:
 # An Ocean of Possibilities
 
 Finley was overwhelmed by the beauty of the ocean. But he also realized that it was never only about reaching his goal. He thought about all the new things he learned during his journey and all the new friends he made.
 
 And in the end, the thing that scared him for so long, leaving his comfort zone behind, was not so scary after all.
 
 Finley's story can also be your story. Do not be afraid to follow your dreams.
 
 **Embrace uncertainty and use it as a tool for growth.**
 
 # THE END
 
 - - -
 
 + Experiment:
    Congratulations! You have now reached the end of the journey. Now let Finley swim around with his new friends in the ocean.
 
    Maybe you have already noticed that this playground features a special movement for the fish in Finley's swarm. It is a simplified model of the real-world behaviour of fish. The movement of each individual fish is based on a compromise between staying together and keeping separated, while staying close to Finley.
 
    Try to create up to 100 fish to observe their swarming behaviour.

*/
//#-code-completion(everything, hide)
//#-hidden-code
import Foundation
import PlaygroundSupport

let page = PlaygroundPage.current
page.needsIndefiniteExecution = true
let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy

class LiveViewListener: PlaygroundRemoteLiveViewProxyDelegate {
    
    func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy,
                             received message: PlaygroundValue) {
        
        guard case .boolean(let win) = message else {
            return
        }
        
        if win {
            PlaygroundPage.current.assessmentStatus = .pass(message: "Great job! Finley's swarm just grew. Have fun swimming around with them!")
        } else {
            PlaygroundPage.current.assessmentStatus = .fail(hints: ["Try to create 1 to 100 followers for Finley"], solution: nil)
        }
    }
    
    func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) { }
}

let listener = LiveViewListener()
proxy.delegate = listener


func addFollowers(amount: Int) {
    
    // Limit amount of food to create
    if amount <= 0 || amount > 100 {
        PlaygroundPage.current.assessmentStatus = .fail(hints: ["Try to create 1 to 100 followers for Finley"], solution: nil)
    } else {
        sendValue(.integer(amount))
    }
    
}
//#-end-hidden-code

addFollowers(amount: /*#-editable-code*/<#T##followers##Int#>/*#-end-editable-code*/)

/*:
 - Notes:
    When playing with Finley, please feel free to extend the live view to fullscreen.
 
    If you want to restart just hit "Stop" and then "Run My Code".
 */

