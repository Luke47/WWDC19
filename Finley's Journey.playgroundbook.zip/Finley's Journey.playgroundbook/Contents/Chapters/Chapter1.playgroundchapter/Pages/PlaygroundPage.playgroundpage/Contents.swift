/*:
 # Living in a Comfort Zone
 
 Finley did not need to worry about anything. Everyday, he was swimming peacefully in his pond.
 
 + Experiment:
 Drag your finger around on the live view or tap on it to move Finley.
 
 Sometimes, humans would pass by to throw food for him into the pond.
 
 ## Challenge
 Finley is feeling hungry. You can create food for him by entering the amount of units in the `createFood` function below (maximum 100) and run your code. Try to create at least 1 unit of food and move Finley to eat it all before it reaches the ground. If you want a bigger challenge, try to add more food.
 
 */
//#-code-completion(everything, hide)
//#-hidden-code
import Foundation
import PlaygroundSupport

let page = PlaygroundPage.current
page.needsIndefiniteExecution = true
let proxy = page.liveView as! PlaygroundRemoteLiveViewProxy

class LiveViewListener: PlaygroundRemoteLiveViewProxyDelegate {
    
    var challengeOn = false
    
    func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy,
                             received message: PlaygroundValue) {
        
        guard case .boolean(let success) = message else {
            return
        }
        
        if success {
            PlaygroundPage.current.assessmentStatus = .pass(message: "Great job! You managed to catch all of the food. As you can see, Finley's life is not very difficult. But also not very exciting and the pond feels a little bit lonely. To see how the story continues, please advance to the [next page](@next).")
        } else {
            PlaygroundPage.current.assessmentStatus = .fail(hints: ["Try to create 1 to 100 units of food and catch them all with Finley before they reach the ground."], solution: nil)
        }
    }
    
    func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) { }
}

let listener = LiveViewListener()
proxy.delegate = listener

func createFood(amount: Int) {
    
    // Limit amount of food to create
    if amount <= 0 || amount > 100 {
        PlaygroundPage.current.assessmentStatus = .fail(hints: ["Try to create 1 to 100 units of food and catch them all with Finley before they reach the ground."], solution: nil)
    } else {
        sendValue(.integer(amount))
    }
    
}
//#-end-hidden-code

createFood(amount: /*#-editable-code*/<#T##number of units##Int#>/*#-end-editable-code*/)

/*:
 - Notes:
    When playing with Finley, please feel free to extend the live view to fullscreen.
 
    If you want to restart just hit "Stop" and then "Run My Code".
*/
