//
//  CGFloatExtensions.swift
//  FinleysJourney
//
//  Created by Lukas Gauster on 21/03/2019.
//

import CoreGraphics

extension CGFloat {
    var degreesToRadians: CGFloat {
        return self * .pi / 180
    }
    
    var radiansToDegrees: CGFloat {
        return self * 180 / .pi
    }
}
