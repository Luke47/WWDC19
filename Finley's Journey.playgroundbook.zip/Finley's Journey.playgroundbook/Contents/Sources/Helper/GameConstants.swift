//
//  GameConstants.swift
//  FishTale
//
//  Created by Lukas Gauster on 19/03/2019.
//

import Foundation
import UIKit

struct GameConstants {
    
    struct NodeNames {
        static let player = "playerFish"
        static let background = "background"
        static let friend = "friend"
        static let enemy = "enemy"
        static let fishCountLabel = "fishCount"
        static let food = "food"
    }
    
    struct NodeImageNames {
        static let player = "player1"
        static let backgroundImageHome = "home2"
        static let backgroundImageRiver = "background4"
        static let backgroundImageOcean = "ocean1"
        static let enemy1 = "enemy1"
        static let enemy2 = "enemy2"
        static let food = "food"
    }
    
    struct NodeSpeed {
        static let defaultFishSpeed = 2
        static let playerFish = 1500
        static let enemyFish1 = 2
        static let enemyFish2 = 5
        static let friend = 4
        static let food = 5
        static let skeleton = 3
    }
    
    struct EnemyLifePoints {
        static let type1 = 5
        static let type2 = 10
    }
    
    struct EnemyDamageToPlayer {
        static let type1 = 5
        static let type2 = 5
    }
    
    struct School {
        static let maxSize = 50
    }
    
    struct PlayGroundConstraints {
        static let maxAmountOfFood = 100
        static let maxAmountOfSchool = 100
    }
    
    struct SpriteMarginsToSceneBorders {
        static let topMargin: CGFloat = 230
        static let bottomMargin: CGFloat = 70
        static let leftMargin: CGFloat = 20
        static let rightMargin: CGFloat = 20
    }
}

