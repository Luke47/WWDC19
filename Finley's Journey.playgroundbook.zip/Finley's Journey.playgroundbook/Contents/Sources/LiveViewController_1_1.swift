//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import Foundation
import PlaygroundSupport
import SpriteKit
import GameplayKit

class LiveViewController_1_1: LiveViewController {
    
    // Scene to handle gameplay
    var sceneForGame: MainGameScene?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        restartGame()
    }
    
    override public func receive(_ message: PlaygroundValue) {
        
        guard case .integer(let messageValue) = message else {
            return
        }
        
        restartGame()
        self.sceneForGame?.createFood(amount: messageValue)
    }
    
    func restartGame() {
        
        if let view = self.view as! SKView? {
            // Load the SKScene from 'GameScene.sks'
            if let scene = MainGameScene(fileNamed: "MainGameScene") {
                
                
                // Set the scale mode to scale to fit the window
                scene.scaleMode = .resizeFill
                scene.backgroundColor = .white
                scene.gameState = .Home
                scene.gameDelegate = self
                
                // Present the scene
                sceneForGame = scene
                view.presentScene(sceneForGame)
            }
            
            view.ignoresSiblingOrder = true
            
//            view.showsFPS = true
//            view.showsNodeCount = true
        }
    }
}

extension LiveViewController_1_1: MainGameSceneDelegate {
    
    func gameWasWon() {
        send(.boolean(true))
    }
    
    func gameWasLost() {
        send(.boolean(false))
    }
}

