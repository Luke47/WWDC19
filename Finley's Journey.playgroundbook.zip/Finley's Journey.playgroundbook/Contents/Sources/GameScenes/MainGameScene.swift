//
//  MainGameScene.swift
//  FishTale
//
//  Created by Lukas Gauster on 17/03/2019.
//

import SpriteKit
import GameplayKit

struct PhysicsCategory {
    static let none     : UInt32 = 0
    static let all      : UInt32 = UInt32.max
    static let player   : UInt32 = 1 << 1
    static let enemy    : UInt32 = 1 << 2
    static let friend   : UInt32 = 1 << 3
    static let food     : UInt32 = 1 << 4
}

enum GameState {
    case Home
    case Travelling
    case Ocean
}

protocol MainGameSceneDelegate {
    func gameWasWon()
    func gameWasLost()
}

class MainGameScene: SKScene {
    
    var gameDelegate: MainGameSceneDelegate?
    
    // Keep track of which state the game is in
    var gameState: GameState = .Home
    
    private var currentSchool = [FriendlyFish]()
    private var maxSchoolSize = GameConstants.School.maxSize
    private var lastUpdateTime: TimeInterval = 0
    private var frameCount: Int = 0
    private let updateFrequency = 31
    
    var fishCountLabel = SKLabelNode()
    
    var foodLeft = 0
    var collectedFood = 0
    var foodWasLost = false
    
    lazy var player: PlayerFish = {
        return PlayerFish()
    }()

    // Sound
    var playEatingSound: SKAction?
    var playNewFollowerSound: SKAction?
    var playWinSound: SKAction?
    var playLoseSound: SKAction?
    
    var delegateAlreadyNotifiedAboutWin = false
    var delegateAlreadyNotifiedAboutLoss = false
    
    // MARK: Scene setup
    override func didMove(to view: SKView) {
        
        loadSounds()
        loadBackground()
        loadFishCountLabel()
        loadPlayer()
        
        delegateAlreadyNotifiedAboutWin = false
        delegateAlreadyNotifiedAboutLoss = false
        

        let backgroundMusic = SKAudioNode(fileNamed: "backgroundMusic.wav")
        backgroundMusic.autoplayLooped = true
        self.addChild(backgroundMusic)
        
        // Set up physics
        physicsWorld.gravity = .zero
        physicsWorld.contactDelegate = self

        if gameState == .Travelling {
            // Start to spawn enemies
            run(SKAction.repeatForever(
                SKAction.sequence([
                    SKAction.wait(forDuration: 1.5),
                    SKAction.run(spawnEnemy)
                    ])
            ))
            
            // Start to spawn friends
            run(SKAction.repeatForever(
                SKAction.sequence([
                    SKAction.wait(forDuration: 1),
                    SKAction.run(spawnFriend)
                    ])
            ))
        }
    }
    
    private func loadSounds() {
        playEatingSound = SKAction.playSoundFileNamed("eating.mp3", waitForCompletion: false)
        playNewFollowerSound = SKAction.playSoundFileNamed("collected.wav", waitForCompletion: false)
        playWinSound = SKAction.playSoundFileNamed("win.wav", waitForCompletion: false)
        playLoseSound = SKAction.playSoundFileNamed("lose.mp3", waitForCompletion: false)
    }
    
    private func loadFishCountLabel() {
        fishCountLabel.removeFromParent()
        fishCountLabel = SKLabelNode(text: "0")
        fishCountLabel.name = GameConstants.NodeNames.fishCountLabel
        fishCountLabel.fontSize = 50
        fishCountLabel.fontColor = .black
        fishCountLabel.position = CGPoint(x: -size.width / 2 + fishCountLabel.frame.size.width / 2 + 40, y: size.height / 2 - fishCountLabel.frame.size.height / 2 - GameConstants.SpriteMarginsToSceneBorders.topMargin - 20)
        
        self.addChild(fishCountLabel)
        updateFishCountLabelWith(count: 0)
    }
    
    private func loadPlayer() {
        self.addChild(player)
        self.applyMovementConstraintsFor(fish: player)
    }
    
    private func applyMovementConstraintsFor(fish: SKSpriteNode) {
        
        // Create constraints to trap a node within the screen and with defined margins to left, right, top, bottom edges of the screen
        let xLimit = SKRange(lowerLimit: -size.width / 2 + GameConstants.SpriteMarginsToSceneBorders.leftMargin + fish.size.width / 2, upperLimit: size.width / 2 - GameConstants.SpriteMarginsToSceneBorders.rightMargin - fish.size.width / 2)
        let yLimit = SKRange(lowerLimit: -size.height / 2 + GameConstants.SpriteMarginsToSceneBorders.bottomMargin + fish.size.height / 2, upperLimit: size.height / 2 - GameConstants.SpriteMarginsToSceneBorders.topMargin - fish.size.height / 2)
        let leftRightConstraint = SKConstraint.positionX(xLimit)
        let topBottomConstraint = SKConstraint.positionY(yLimit)
        
        // Apply constraints
        if let _ = fish as? FriendlyFish {
            fish.constraints = [topBottomConstraint]
        } else {
            fish.constraints = [leftRightConstraint, topBottomConstraint]
        }
    }
    
    override func didChangeSize(_ oldSize: CGSize) {
        
        // Remove all backgrounds and re-add them to fit new screen orientation
        self.enumerateChildNodes(withName: GameConstants.NodeNames.background, using: { (backgroundNode, _)  in
            backgroundNode.removeAllActions()
            backgroundNode.removeFromParent()
        })
        
        // Re-add the backbgrounds
        self.loadBackground()
        
        self.loadFishCountLabel()
        
        if gameState == .Home {
            updateFishCountLabelWith(count: collectedFood)
        } else {
            updateFishCountLabelWith(count: currentSchool.count)
        }

        // Re-apply constraints to all elements that need it!
        self.applyMovementConstraintsFor(fish: player)
        self.enumerateChildNodes(withName: GameConstants.NodeNames.friend, using: { (friend, _)  in
            if let friend = friend as? FriendlyFish {
               self.applyMovementConstraintsFor(fish: friend)
            }
        })
    }
    
    private func loadBackground() {
        
        if gameState == .Home {
            let backgroundTexture = SKTexture(imageNamed: GameConstants.NodeImageNames.backgroundImageHome)
            let background = prepareBackgroundWith(texture: backgroundTexture)
            background.anchorPoint = CGPoint.zero
            background.position = CGPoint(x: -backgroundTexture.size().width / 2, y: -self.frame.height / 2)
            addChild(background)
        } else if gameState == .Travelling {
            for i in 0 ... 1 {
                let backgroundTexture = SKTexture(imageNamed: GameConstants.NodeImageNames.backgroundImageRiver)
                let background = prepareBackgroundWith(texture: backgroundTexture)
                background.anchorPoint = CGPoint.zero
                background.position = CGPoint(x: (backgroundTexture.size().width * CGFloat(i) - self.frame.width / 2) - CGFloat(i * 1), y: -self.frame.height / 2)
                addChild(background)
                
                let moveLeft = SKAction.moveBy(x: -backgroundTexture.size().width, y: 0, duration: 20)
                let moveReset = SKAction.moveBy(x: backgroundTexture.size().width, y: 0, duration: 0)
                let moveLoop = SKAction.sequence([moveLeft, moveReset])
                let moveForever = SKAction.repeatForever(moveLoop)
                background.run(moveForever)
            }
        } else if gameState == .Ocean {
            for i in 0 ... 1 {
                let backgroundTexture = SKTexture(imageNamed: GameConstants.NodeImageNames.backgroundImageOcean)
                let background = prepareBackgroundWith(texture: backgroundTexture)
                background.anchorPoint = CGPoint.zero
                background.position = CGPoint(x: (backgroundTexture.size().width * CGFloat(i) - self.frame.width / 2) - CGFloat(i * 1), y: -self.frame.height / 2)
                addChild(background)
                
                let moveLeft = SKAction.moveBy(x: -backgroundTexture.size().width, y: 0, duration: 20)
                let moveReset = SKAction.moveBy(x: backgroundTexture.size().width, y: 0, duration: 0)
                let moveLoop = SKAction.sequence([moveLeft, moveReset])
                let moveForever = SKAction.repeatForever(moveLoop)
                background.run(moveForever)
            }
        }
    }
    
    private func prepareBackgroundWith(texture: SKTexture) -> SKSpriteNode {
        
        let background = SKSpriteNode(texture: texture)
        background.name = GameConstants.NodeNames.background
        
        // Set scalable area of the background image and scale it to fill the screen
        background.centerRect = CGRect(x: 200 / background.frame.width, y: 215 / background.frame.height, width: 20 / background.frame.width, height: 400 / background.frame.height)
        background.xScale = 1
        background.yScale = self.frame.height / background.size.height
        background.zPosition = -130
        
        return background
    }
    
    // MARK: Game State updates
    private func playerWasKilled() {
        
        // The player was eaten
        self.spawnSkeletonAtPositionFor(fish: player)
        player.removeFromParent()
        
        // Remove all followers (but at this point none of them should be remaining, because they defended the player)
        for fish in currentSchool {
            fish.removeFromParent()
        }
        
        self.gameLost()
    }
    
    private func gameLost() {
        
        guard !delegateAlreadyNotifiedAboutLoss, let gameDelegate = gameDelegate, let playLoseSound = playLoseSound else {
            return
        }
        
        delegateAlreadyNotifiedAboutLoss = true
        
        run(playLoseSound)
        gameDelegate.gameWasLost()
    }
    
    private func gameWon() {
        
        guard !delegateAlreadyNotifiedAboutWin, let gameDelegate = gameDelegate, let playWinSound = playWinSound else {
            return
        }
        
        delegateAlreadyNotifiedAboutWin = true
        
        run(playWinSound)
        gameDelegate.gameWasWon()
    }
    
    func pauseGame() {
        self.isPaused = true
    }
    
    func continueGame() {
        self.isPaused = false
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Update the player
        player.update(interval: currentTime)
        
        // Update the school of fish
        let deltaTime: TimeInterval = lastUpdateTime == 0 ? 0 : currentTime - lastUpdateTime
        lastUpdateTime = currentTime
        frameCount += 1
        
        for fish in currentSchool {
            
            // Update the school property of a fish every so often
            if frameCount % updateFrequency == 0 {
                DispatchQueue.global(qos: .background).async {
                    
                    let startTime = Date()
                    fish.school = self.currentSchool.filter { $0 !== self }
                    
                    DispatchQueue.main.async {
                        fish.update(interval: -startTime.timeIntervalSinceNow)
                    }
                }
            } else {
                fish.update(interval: deltaTime)
            }
        }
    }
    
}

// MARK: - Spawning fish
extension MainGameScene {
    
    private func spawnEnemy() {
        self.spawnFishOf(type: .Enemy)
    }
    
    private func spawnFriend() {
        self.spawnFishOf(type: .Friend)
    }
    
    private func spawnFishOf(type: FishType) {
        
        var newFish: Fish
        
        switch type {
        case .Enemy:
            newFish = EnemyFish()
        case .Friend:
            newFish = FriendlyFish()
        }

        // Get the spawn position
        let randomYGenerator = createRandomPositionGeneratorToSpawn(fish: newFish)
        let yPosition = randomYGenerator.nextInt()
        let xPosition = CGFloat(size.width / 2 + newFish.frame.width / 2)

        // Position the fish slightly off-screen along the right edge,
        // and along a random position along the Y axis as calculated above
        newFish.position = CGPoint(x: xPosition, y: CGFloat(yPosition))
        newFish.zPosition = -1
        
        // Add the fish to the scene
        addChild(newFish)
        
        // Create the actions
        let actionMove = SKAction.move(to: CGPoint(x: -size.width/2 - newFish.frame.width/2, y: CGFloat(yPosition)),
                                       duration: TimeInterval(newFish.getSpeed()))
        
        let actionMoveDone = SKAction.removeFromParent()
        newFish.run(SKAction.sequence([SKAction.wait(forDuration: Double.random(in: 1...5)), actionMove, actionMoveDone]))
        
    }
    
    private func spawnSkeletonAtPositionFor(fish: Fish) {
        
        // First, get the texture of the skeleton based on the type of fish, that died
        var textureName: String = ""
        
        if let friendFish = fish as? FriendlyFish {
            if let indexOfType = FriendType.allCases.firstIndex(of: friendFish.type) {
                textureName = "skeleton\(indexOfType + 1)"
            }
        } else if let _ = fish as? PlayerFish {
            textureName = "skeletonPlayer"
        } else if let _ = fish as? EnemyFish {
            textureName = "skeletonEnemy"
        }
        
        if textureName == "" {
            return
        }
        
        let texture = SKTexture(imageNamed: textureName)
        let skeleton = SKSpriteNode(texture: texture)
        
        skeleton.position = CGPoint(x: fish.position.x, y: fish.position.y)
        skeleton.zPosition = -1
        
        // Add the skeleton to the scene
        addChild(skeleton)
        
        // Create the actions
        // We need to also consider the movement of background / current so skeletons are falling straight down and it does not appear like they are moving
        let actionMove = SKAction.move(to: CGPoint(x: fish.position.x - 200,
                                                   y: -size.height / 2 + GameConstants.SpriteMarginsToSceneBorders.bottomMargin + skeleton.size.height / 2),
                                       duration: TimeInterval(GameConstants.NodeSpeed.skeleton))
        
        let actionMoveDone = SKAction.removeFromParent()
        skeleton.run(SKAction.sequence([actionMove, actionMoveDone]))
        
    }
    
    private func createRandomPositionGeneratorToSpawn(fish: SKSpriteNode) -> GKRandomDistribution {
    
        // Randomly determine where to spawn the fish along the Y axis
        return GKRandomDistribution(lowestValue: Int(-self.frame.height / 2 + fish.frame.height / 2 + GameConstants.SpriteMarginsToSceneBorders.bottomMargin),
                                    highestValue: Int(self.frame.height / 2 - fish.frame.height / 2 - GameConstants.SpriteMarginsToSceneBorders.topMargin))
    
    }
}

// MARK: Ocean: Create followers
extension MainGameScene {
    func createFollowers(amount: Int) {
        
        var amountToCreate = amount
        
        if amountToCreate > GameConstants.PlayGroundConstraints.maxAmountOfSchool {
            amountToCreate = GameConstants.PlayGroundConstraints.maxAmountOfSchool
        }
        
        maxSchoolSize = amountToCreate
        
        for _ in 0..<amountToCreate {
            let newFollower = FriendlyFish()
            let randomYGenerator = GKRandomDistribution(lowestValue: Int(-self.frame.height / 2 + newFollower.frame.height / 2 + GameConstants.SpriteMarginsToSceneBorders.bottomMargin),
                                                               highestValue: Int(self.frame.height / 2 - newFollower.frame.height / 2 - GameConstants.SpriteMarginsToSceneBorders.topMargin))
            let randomXGenerator = GKRandomDistribution(lowestValue: Int(-self.frame.width / 2 + newFollower.frame.width / 2 + GameConstants.SpriteMarginsToSceneBorders.leftMargin),
                                                        highestValue: Int(self.frame.width / 2 - newFollower.frame.width / 2 - GameConstants.SpriteMarginsToSceneBorders.rightMargin))
            let yPosition = randomYGenerator.nextInt()
            let xPosition = randomXGenerator.nextInt()
            
            newFollower.position = CGPoint(x: xPosition, y: yPosition)
            newFollower.zPosition = -1
            self.addChild(newFollower)
            self.addNewFollower(fishToAdd: newFollower)
        }
        
        if gameState == .Ocean {
            // Immediate win in this mode
            self.gameWon()
        }
        
        updateFishCountLabelWith(count: currentSchool.count)
    }
}

// MARK: Spawn Food
extension MainGameScene {
    
    func createFood(amount: Int) {
        
        foodWasLost = false
        collectedFood = 0
        updateFishCountLabelWith(count: 0)
        
        var amountToCreate = amount
        
        if amountToCreate > GameConstants.PlayGroundConstraints.maxAmountOfFood {
            amountToCreate = GameConstants.PlayGroundConstraints.maxAmountOfFood
        }
        
        foodLeft = amountToCreate
        
        // First, remove all existing food
        self.enumerateChildNodes(withName: GameConstants.NodeNames.food, using: { (food, _) in
            food.removeFromParent()
        })
        
        // Start to spawn new food
        run(SKAction.repeat(SKAction.sequence([
            SKAction.wait(forDuration: 0.5),
            SKAction.run(spawnFood)
            ]), count: amountToCreate))
    }
    
    private func spawnFood() {

        let foodTexture = SKTexture(imageNamed: GameConstants.NodeImageNames.food)
        let food = SKSpriteNode(texture: foodTexture)
        food.name = GameConstants.NodeImageNames.food
        food.anchorPoint = CGPoint.zero
        
        let yPosition = size.height / 2 - GameConstants.SpriteMarginsToSceneBorders.topMargin - food.size.height / 2
        let randomXGenerator = createRandomXGeneratorToSpawn(food: food)
        let xPosition = randomXGenerator.nextInt()
        
        food.position = CGPoint(x: CGFloat(xPosition), y: yPosition)
        food.zPosition = -1
        
        // Add player's physics body
        food.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: food.frame.width, height: food.frame.height))
        food.physicsBody?.isDynamic = true
        food.physicsBody?.categoryBitMask = PhysicsCategory.food
        food.physicsBody?.contactTestBitMask = PhysicsCategory.none
        food.physicsBody?.collisionBitMask = PhysicsCategory.none
        
        food.physicsBody?.allowsRotation = false
        
        addChild(food)
        
        // Make the food fall down
        let actionMove = SKAction.move(to: CGPoint(x: CGFloat(xPosition), y: -size.height / 2 + GameConstants.SpriteMarginsToSceneBorders.bottomMargin + food.size.height / 2), duration: TimeInterval(GameConstants.NodeSpeed.food))
        
        let actionMoveDone = SKAction.removeFromParent()
        food.run(SKAction.sequence([actionMove,
                                    SKAction.run(foodReachedGround),
                                    actionMoveDone]))
    }
    
    private func foodReachedGround() {
        
        // Check if game was already marked as lost
        if !foodWasLost {
            foodWasLost = true
            self.gameLost()
        }

    }
    
    private func checkIfFoodLeft() {
        
        if foodLeft <= 0 {
            self.gameWon()
        }
        
    }
    
    private func createRandomXGeneratorToSpawn(food: SKSpriteNode) -> GKRandomDistribution {
        return GKRandomDistribution(lowestValue: Int(-self.frame.width / 2 + food.frame.width / 2 + GameConstants.SpriteMarginsToSceneBorders.leftMargin),
                                    highestValue: Int(self.frame.width / 2 - food.frame.width / 2 - GameConstants.SpriteMarginsToSceneBorders.rightMargin))
    }
}

// MARK: Adding / Removing fish from the current school
extension MainGameScene {

    private func addNewFollower(fishToAdd: FriendlyFish) {
        
        // Only add follower, if maximum school size not yet reached
        if self.currentSchool.count >= maxSchoolSize {
            return
        }
        
        // Stop all actions of the fish
        fishToAdd.removeAllActions()
        
        // Update fish properties
        fishToAdd.isPartOfSchool = true
        fishToAdd.xScale = 1
        fishToAdd.schoolCenter = player.position
        
        self.applyMovementConstraintsFor(fish: fishToAdd)
        
        // Update school properties
        currentSchool.append(fishToAdd)
        fishToAdd.school = self.currentSchool.filter { $0 !== self }
        
        updateFishCountLabelWith(count: currentSchool.count)
        
        checkIfEnoughFollowers()
    }
    
    private func removeFollower(fishToRemove: FriendlyFish) {
        
        // Get the index of the fish and remove it from the school
        if let index = currentSchool.firstIndex(of: fishToRemove) {
            
            currentSchool.remove(at: index)
            
            // Update the school properties of each fish
            for fish in currentSchool {
                fish.school = self.currentSchool.filter { $0 !== self }
            }
        }
        
        updateFishCountLabelWith(count: currentSchool.count)
    }
    
    private func updateFishCountLabelWith(count: Int) {
        fishCountLabel.text = "\(count)"
    }
    
    private func checkIfEnoughFollowers() {
        
        if self.currentSchool.count >= 30 && gameState == .Travelling {
            self.gameWon()
        }
        
    }
}

// MARK: - Touch handling
extension MainGameScene {
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if let destination = touches.first {
            player.touchPoint = destination
            player.travelling = true
        }

        touchesMoved(touches, with: event)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        player.travelling = true
        
        // Send all fish to the location we tapped with the finger
        // If we apply the seek behavior, they will move faster until they have reached their target
        if let touchPosition = touches.first?.location(in: self) {
            for fish in currentSchool {
                // Update center of the school (player will move there too, so touchposition will be the player position)
                fish.schoolCenter = touchPosition
                // Move fish to new position
                fish.seek(touchPosition)
            }
        }
    }
}

// MARK: Handle Contact Events
extension MainGameScene: SKPhysicsContactDelegate  {
    func didBegin(_ contact: SKPhysicsContact) {
        
        // Order bodies depending on categoryBitMask
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        } else {
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        
        if ((firstBody.categoryBitMask & PhysicsCategory.player != 0) &&
            (secondBody.categoryBitMask & PhysicsCategory.friend != 0)) {
            if let fish = secondBody.node as? FriendlyFish {
                self.playerDidHitFriend(friend: fish)
            }
        } else if ((firstBody.categoryBitMask & PhysicsCategory.player != 0) &&
            (secondBody.categoryBitMask & PhysicsCategory.enemy != 0)) {
            if let enemy = secondBody.node as? EnemyFish{
                self.enemyDidHitPlayer(enemy: enemy)
            }
        } else if ((firstBody.categoryBitMask & PhysicsCategory.enemy != 0) &&
            (secondBody.categoryBitMask & PhysicsCategory.friend != 0)) {
            if let enemy = firstBody.node as? EnemyFish, let fish = secondBody.node as? FriendlyFish {
                self.enemyDidHitFriend(enemy: enemy, friend: fish)
            }
        } else if ((firstBody.categoryBitMask & PhysicsCategory.player != 0) &&
            (secondBody.categoryBitMask & PhysicsCategory.food != 0)) {
            // Eat food, remove it from the scene
            if let food = secondBody.node as? SKSpriteNode {
                self.playerDidHitFood(food: food)
            }
        }
    }
    
    private func playerDidHitFriend(friend: FriendlyFish) {
        if !friend.isPartOfSchool {
            
            if let playNewFollowerSound = playNewFollowerSound {
                run(playNewFollowerSound)
            }
            
            self.addNewFollower(fishToAdd: friend)
        }
    }
    
    private func playerDidHitFood(food: SKSpriteNode) {
        // Eat food, remove it from the scene
        if let playEatingSound = playEatingSound {
            run(playEatingSound)
        }
        food.removeFromParent()
        foodLeft -= 1
        collectedFood += 1
        updateFishCountLabelWith(count: collectedFood)
        checkIfFoodLeft()
    }
    
    private func enemyDidHitPlayer(enemy: EnemyFish) {
        
        // Player was hit, but his friends can protect him
        var damageDealt = 0
        switch enemy.type {
        case .Enemy1:
            damageDealt = GameConstants.EnemyDamageToPlayer.type1
        case .Enemy2:
            damageDealt = GameConstants.EnemyDamageToPlayer.type2
        }
        
        // Remove as many fish from the swarm, as damage was dealt
        if damageDealt > currentSchool.count {
            // Not enough fish to block the damage
            // Player is killed
            if let playEatingSound = playEatingSound {
                run(playEatingSound)
            }
            self.playerWasKilled()
        } else {
            // Enemy instead hits fish of the school
            for _ in 0..<damageDealt {
                if let friend = currentSchool.last {
                    self.enemyDidHitFriend(enemy: enemy, friend: friend)
                }
            }
        }
    }
    
    private func enemyDidHitFriend(enemy: EnemyFish, friend: FriendlyFish) {
        
        // Only act, if the fish is part of the player's current school
        if friend.isPartOfSchool {
            
            // Remove the bitmask so this is not triggered multiple times
            friend.physicsBody?.categoryBitMask = 0
            
            if let playEatingSound = playEatingSound {
                run(playEatingSound)
            }
            
            // Spawn a skeleton for this fish and remove him from the scene
            spawnSkeletonAtPositionFor(fish: friend)
            friend.removeFromParent()
            
            // Remove him from the current school
            self.removeFollower(fishToRemove: friend)
            
            // Decrease life points of the enemy
            enemy.lifePoints -= 1
            
            // Check if he is dead
            if enemy.lifePoints <= 0 {
                // He is dead!
                // Remove the bitmask
                enemy.physicsBody?.categoryBitMask = 0
                // Spawn a skeleton for this fish and remove him from the scene
                spawnSkeletonAtPositionFor(fish: enemy)
                enemy.removeFromParent()
            }
        }
    }
}
