//
//  PlayerFish.swift
//  FishTale
//
//  Created by Lukas Gauster on 19/03/2019.
//

import SpriteKit

class PlayerFish: Fish {

    var touchPoint: UITouch?
    var travelling: Bool = false
    
    private var lastInterval: TimeInterval?
    private let brakeDistance: CGFloat = 4.0
    
    
    init() {
        
        let texture = SKTexture(imageNamed: GameConstants.NodeImageNames.player)
        super.init(texture: texture, color: .clear, size: texture.size())
        
        self.setScale(1.0)
        self.name = GameConstants.NodeNames.player
        self.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        self.position = CGPoint(x: 0.0, y: 0.0)
        
        // Add player's physics body
        self.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: self.frame.width, height: self.frame.height))
        self.physicsBody?.isDynamic = true
        self.physicsBody?.categoryBitMask = PhysicsCategory.player
        self.physicsBody?.contactTestBitMask = PhysicsCategory.friend | PhysicsCategory.food
        self.physicsBody?.collisionBitMask = PhysicsCategory.none
        
        self.physicsBody?.allowsRotation = false
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func update(interval: TimeInterval) {
        
        if lastInterval == nil {
            lastInterval = interval
        }
        
        let delta: TimeInterval = interval - lastInterval!
        
        if travelling {
            if let gameScene = scene, let destination = touchPoint?.location(in: gameScene) {
                travelTowardsPoint(point: destination, byTimeDelta: delta)
            }
        }
        
        lastInterval = interval
    }
    
    private func travelTowardsPoint(point: CGPoint, byTimeDelta timeDelta: TimeInterval) {
        
        let distanceLeft = sqrt(pow(position.x - point.x, 2) + pow(position.y - point.y, 2))
        
        if (distanceLeft > brakeDistance) {
            
            // Calculate the next distance to travel
            var distanceToTravel = CGFloat(timeDelta) * CGFloat(getSpeed())
            
            // But it should not be more than the total distance left or else we will shoot over the target destination
            if distanceToTravel > distanceLeft {
                distanceToTravel = distanceLeft
            }
            
            let angle = atan2(point.y - position.y, point.x - position.x)
            let yOffset = distanceToTravel * sin(angle)
            let xOffset = distanceToTravel * cos(angle)
            
            position = CGPoint(x: position.x + xOffset, y: position.y + yOffset)
        }
    }
    
    override func getSpeed() -> Int {
        return GameConstants.NodeSpeed.playerFish
    }
}
