//
//  Fish.swift
//  FishTale
//
//  Created by Lukas Gauster on 17/03/2019.
//

import SpriteKit

enum FishType {
    case Enemy
    case Friend
}

class Fish: SKSpriteNode {
    
    func getSpeed() -> Int {
        return GameConstants.NodeSpeed.defaultFishSpeed
    }
    
}
