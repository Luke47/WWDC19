//
//  FishBehavior.swift
//  FinleysJourney
//
//  Created by Lukas Gauster on 21/03/2019.
//

// Core Behaviors Algorithm : http://www.kfish.org/boids/pseudocode.html
// Behavior protocols inspired by https://github.com/christopherkriens/boids

import UIKit
import GameplayKit

/**
 All behaviors must adopt this protocol. Behaviors are expected to calculate
 a result vector based on the behavior rules and apply an intensity
 */
protocol FishBehavior: AnyObject {
    /// The result velocity after the calculation
    var velocity: CGPoint { get }
    
    /// The intensity applied to the velocity, bounded 0.0 to 1.0
    var intensity: CGFloat { get set }
    
    init(intensity: CGFloat)
    
    init()
}

/**
 This extension provides a default implementation for initialization,
 as well as a computed property for accessing the scaled vector.
 */
extension FishBehavior {
    init(intensity: CGFloat) {
        self.init()
        self.intensity = intensity
        
        // Ensure that intensity gets capped between 0 and 1
        let valid: ClosedRange<CGFloat> = 0.0...1.0
        guard valid.contains(intensity) else {
            self.intensity = (round(intensity) > valid.upperBound/2) ? valid.lowerBound : valid.upperBound
            return
        }
    }
    
    var scaledVelocity: CGPoint {
        return velocity * intensity
    }
}

/**
 This behavior applies a tendency to move the fish towards a given position.
 */
final class Cohesion: FishBehavior {
    var velocity: CGPoint = CGPoint.zero
    var intensity: CGFloat = 0.0
    
    func apply(toFish fish: FriendlyFish, withCenterOfSchool center: CGPoint) {
        velocity = (center - fish.position)
    }
}

/**
 This behavior applies a tendency to move away from neighbors when
 they get too close together, so they do not stack on top of each other.
 */
final class Separation: FishBehavior {
    var velocity: CGPoint = CGPoint.zero
    var intensity: CGFloat = 0.0
    
    func apply(toFish fish: FriendlyFish, inSchool school: [FriendlyFish]) {
        velocity = CGPoint.zero
        
        for schoolFish in school {
            guard schoolFish != fish else {
                continue
            }
            
            if fish.position.distance(from: schoolFish.position) < fish.radius * 2 {
                let awayVector = (schoolFish.position - fish.position)
                velocity -= awayVector * (1 / fish.position.distance(from: schoolFish.position))
            }
        }
    }
}

/**
 This behavior applies a tendency for a fish to move toward a
 particular point. Seek is a temporary behavior that removes
 itself from the fish once the goal is reached.
 */
final class Seek: FishBehavior {
    var intensity: CGFloat = 0.0
    var velocity: CGPoint = CGPoint.zero
    var point: CGPoint = CGPoint.zero
    
    convenience init(intensity: CGFloat, point: CGPoint) {
        self.init(intensity: intensity)
        self.point = point
    }
    
    func apply(fish: FriendlyFish) {
        
        // Approximate touch size
        let goalThreshhold: CGFloat = 60.0
        
        // Remove this behavior once the goal has been reached
        guard fish.position.outside(goalThreshhold, of: point) else {
            fish.currentSpeed = fish.maximumSchoolSpeed
            fish.behaviors = fish.behaviors.filter { $0 as? Seek !== self }
            return
        }
        
        fish.currentSpeed = fish.maximumGoalSpeed
        velocity = (point - fish.position)
    }
}

