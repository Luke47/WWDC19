
//
//  EnemyFish.swift
//  Book_Sources
//
//  Created by Lukas Gauster on 18/03/2019.
//

import SpriteKit

enum EnemyType: CaseIterable {
    case Enemy1
    case Enemy2
}

class EnemyFish: Fish {
    
    var type: EnemyType = .Enemy1
    var lifePoints = 0
    
    init() {
        
        var texture: SKTexture
        
        // Generate a random enemy (out of all available types)
        switch Int.random(in: 1...EnemyType.allCases.count) {
        case 1:
            type = . Enemy1
            texture = SKTexture(imageNamed: GameConstants.NodeImageNames.enemy1)
            lifePoints = GameConstants.EnemyLifePoints.type1
        case 2:
            type = . Enemy2
            texture = SKTexture(imageNamed: GameConstants.NodeImageNames.enemy2)
            lifePoints = GameConstants.EnemyLifePoints.type2
        default:
            type = . Enemy1
            texture = SKTexture(imageNamed: GameConstants.NodeImageNames.enemy1)
            lifePoints = GameConstants.EnemyLifePoints.type1
        }
        
        super.init(texture: texture, color: .clear, size: texture.size())
        
        // Add enemy physics body
        self.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: self.frame.width, height: self.frame.height))
        self.physicsBody?.isDynamic = true
        self.physicsBody?.categoryBitMask = PhysicsCategory.enemy
        self.physicsBody?.contactTestBitMask = PhysicsCategory.friend | PhysicsCategory.player
        self.physicsBody?.collisionBitMask = PhysicsCategory.none
        self.physicsBody?.allowsRotation = false
        
        self.name = GameConstants.NodeNames.enemy
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func getSpeed() -> Int {
        switch type {
        case .Enemy1:
            return GameConstants.NodeSpeed.enemyFish1
        case .Enemy2:
            return GameConstants.NodeSpeed.enemyFish2
        }
    }
    
}
