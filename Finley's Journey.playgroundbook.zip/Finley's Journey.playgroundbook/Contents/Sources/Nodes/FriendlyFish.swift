//
//  FriendlyFish.swift
//  FishTale
//
//  Created by Lukas Gauster on 19/03/2019.
//

import SpriteKit

// When fish move together as a group, this swarming behavior is called schooling
// So it is a school of fish (= swarm of fish)
// All instances of FriendlyFish are capable in moving together as a school to follow the player
// This behavior is only applied, if the fish was added to a school
// If the fish is on its own, no custom behavior is applied

enum FriendType: CaseIterable {
    case Friend1
    case Friend2
    case Friend3
    case Friend4
}

class FriendlyFish: Fish {
    
    var isPartOfSchool = false
    var school: [FriendlyFish] = [FriendlyFish]()
    var schoolCenter = CGPoint.zero
    var behaviors = [FishBehavior]()
    
    let momentum: CGFloat = 6
    var maximumSchoolSpeed: CGFloat = 2
    var maximumGoalSpeed: CGFloat = 4
    var currentSpeed: CGFloat = 2
    var velocity = CGPoint.zero
    lazy var radius: CGFloat = { return min(size.width, size.height) }()
    
    var type: FriendType = .Friend1

    init() {
        
        // Create a random friendly fish
        let randomIndex = Int.random(in: 0..<FriendType.allCases.count)
        let texture = SKTexture(imageNamed: "friend\(randomIndex + 1)")
        
        super.init(texture: texture, color: .clear, size: texture.size())
        
        type = FriendType.allCases[randomIndex]
        
        anchorPoint = CGPoint(x: 0.5, y: 0.5)
        self.xScale = -1
        name = GameConstants.NodeNames.friend
        
        // Assign slightly randomized speeds for variety in flock movement
        let randomSchoolSpeed = CGFloat.random(in: 1...2)
        let randomGoalSpeed = CGFloat.random(in: 5...6)
        self.maximumSchoolSpeed = randomSchoolSpeed
        self.maximumGoalSpeed = randomGoalSpeed
        
        // Add physics body
        self.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: self.frame.width, height: self.frame.height))
        self.physicsBody?.isDynamic = true
        self.physicsBody?.categoryBitMask = PhysicsCategory.friend
        self.physicsBody?.collisionBitMask = PhysicsCategory.none
        self.physicsBody?.allowsRotation = false
        
        
        // School and behaviors
        self.isPartOfSchool = false
        behaviors = [Cohesion(intensity: 0.05),
                     Separation(intensity: 1)]
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    // MARK: - Movement
    
    // Apply a behavior that causes the fish to move towards a given location with higher speed
    // Return to normal speed after location was reached (behavior is automatically removed after goal was reached)
    func seek(_ point: CGPoint) {
        // Remove existing Bound and Seek behaviors, as they conflict
        behaviors = behaviors.filter { !($0 is Seek) }
        
        // If there is a seek behavior in place, reuse it
        if let seek = behaviors.compactMap({ $0 as? Seek }).first {
            seek.point = point
        } else {
            behaviors.append(Seek(intensity: 0.03, point: point))
        }
    }
    
    // Update position of the fish / move the fish
    func update(interval: TimeInterval) {
        
        // Apply each of the fish's behaviors
        for behavior in behaviors {
            // Fish stick together
            // School center typically is the player fish
            // Fish will circle slowly around the player fish if it does not move much
            if let cohesion = behavior as? Cohesion {
                cohesion.apply(toFish: self, withCenterOfSchool: schoolCenter)
                continue
            }
            // But also try to not overlap
            if let separation = behavior as? Separation {
                separation.apply(toFish: self, inSchool: school)
                continue
            }
            // We can send the fish to a certain location with higher speed (if the player fastly moves away from the fish)
            if let seek = behavior as? Seek {
                seek.apply(fish: self)
                continue
            }
        }
        
        // Sum the velocities supplied by each of the behaviors
        velocity += behaviors.reduce(velocity) { $0 + $1.scaledVelocity } / momentum
        
        // Limit the maximum velocity per update
        limitSpeed()
        
        // Update the position on screen
        position += velocity * (CGFloat(interval) * 60)
    }
    
    // MARK: Helper functions
    private func limitSpeed() {
        let vector = velocity.length
        if vector > currentSpeed {
            let unitVector = velocity / vector
            velocity = unitVector * currentSpeed
        }
    }
    
    override func getSpeed() -> Int {
        return GameConstants.NodeSpeed.friend
    }
}

